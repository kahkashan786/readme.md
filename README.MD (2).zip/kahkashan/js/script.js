
function toggle(){
    var sec = document.getElementById('sec');
    var navi = document.getElementById('nav');
    sec.classList.toggle('active');
    navi.classList.toggle('active');

  }
  var myVar = document.getElementById("temp");
  
  
  myVar.addEventListener("mouseenter", function( event ) {   
    event.target.style.color = '#ff8591';
    setTimeout(function() {
      event.target.style.color = "";
    }, 600);
  }, false);
  
  
  
  myVar.addEventListener("mouseover", function( event ) {   
    event.target.style.color = '#0049e8';

    setTimeout(function() {
      event.target.style.color = "";
    }, 400);
  }, false);




function popform(){
var formbtn = document.getElementById("form-open");

var formdiv = document.getElementById("myform");


  formdiv.classList.toggle('form-active');

}

function closeform(){
  var cross = document.getElementById("cross-btn");
  var formdiv = document.getElementById("myform");
  document.getElementById('name').value = '';
  document.getElementById('email').value = '';
  document.getElementById('msg').value = '';
  formdiv.classList.remove('form-active');

}

function validateform(){
  var name = document.getElementById('name').value;
  var email = document.getElementById('email').value;
  var msg = document.getElementById('msg').value;

  if(name == "" || email == ""||msg == "")
    alert('Fill in all details!');
  else
    window.location.href = "index.html";

}